create view goods_list_outstore as (select `ird`.`id`                     AS `id3`,
                                           `ird`.`igoods_definition`      AS `goods_id3`,
                                           `glfi`.`type_id3`              AS `type_id3`,
                                           `glfi`.`brand3`                AS `brand3`,
                                           `glfi`.`name3`                 AS `name3`,
                                           `glfi`.`type_name3`            AS `type_name3`,
                                           `glfi`.`specification3`        AS `specification3`,
                                           `glfi`.`supplier_id3`          AS `supplier_id3`,
                                           `glfi`.`supplier_name3`        AS `supplier_name3`,
                                           `glfi`.`service_tel3`          AS `service_tel3`,
                                           `glfi`.`measurement_unit_id3`  AS `measurement_unit_id3`,
                                           `glfi`.`measurementUnit_name3` AS `measurementUnit_name3`,
                                           `inre`.`instock_time`          AS `instock_time3`,
                                           `ird`.`quantity`               AS `quantity3`,
                                           `ird`.`warranty_end_date`      AS `warranty_end_date3`,
                                           `ird`.`instock_no`             AS `instock_no3`
                                    from ((`assets_tracking`.`asset_instock_record_detail` `ird` left join `assets_tracking`.`goods_list_for_instore` `glfi` on ((
                                      `ird`.`igoods_definition` =
                                      `glfi`.`id3`))) left join `assets_tracking`.`asset_instock_record` `inre` on ((
                                      `ird`.`instock_no` = `inre`.`instock_no`)))
                                    where (`ird`.`is_deleted` = 0));

