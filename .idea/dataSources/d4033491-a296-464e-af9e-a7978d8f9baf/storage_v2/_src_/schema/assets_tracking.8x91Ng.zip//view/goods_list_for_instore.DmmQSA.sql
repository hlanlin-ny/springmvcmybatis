create view goods_list_for_instore as (select `goods`.`id`                  AS `id3`,
                                              `goods`.`id`                  AS `goods_id3`,
                                              `goods`.`category_id`         AS `type_id3`,
                                              `goods`.`brand`               AS `brand3`,
                                              `goods`.`name`                AS `name3`,
                                              `gtype`.`name`                AS `type_name3`,
                                              `goods`.`specification`       AS `specification3`,
                                              `goods`.`supplier_id`         AS `supplier_id3`,
                                              `supp`.`name`                 AS `supplier_name3`,
                                              `supp`.`service_tel`          AS `service_tel3`,
                                              `goods`.`measurement_unit_id` AS `measurement_unit_id3`,
                                              `mu`.`name`                   AS `measurementUnit_name3`
                                       from (((`assets_tracking`.`asset_definition` `goods` left join `assets_tracking`.`asset_category` `gtype` on ((
                                         `goods`.`category_id` =
                                         `gtype`.`id`))) left join `assets_tracking`.`asset_supplier` `supp` on ((
                                         `goods`.`supplier_id` =
                                         `supp`.`id`))) left join `assets_tracking`.`measurement_unit` `mu` on ((
                                         `goods`.`measurement_unit_id` = `mu`.`id`)))
                                       where (`goods`.`is_deleted` = 0));

