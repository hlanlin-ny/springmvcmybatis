create view `zqh-22-113600005` as
  select `intelligence_management_02`.`medical_newborn_record_transfer`.`XM`         AS `XM`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`XB`         AS `XB`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`XB_DMMS`    AS `XB_DMMS`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`CSRQ`       AS `CSRQ`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`GMSFZH`     AS `GMSFZH`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`JSJGMC`     AS `JSJGMC`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`JTZZ_DZMC`  AS `JTZZ_DZMC`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`XXDJSJ`     AS `XXDJSJ`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`MQ_XM`      AS `MQ_XM`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`MQ_MZ`      AS `MQ_MZ`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`MQ_MZ_DMMS` AS `MQ_MZ_DMMS`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`MQ_GMSFZH`  AS `MQ_GMSFZH`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`MQ_LXDH`    AS `MQ_LXDH`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`FQ_XM`      AS `FQ_XM`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`FQ_MZ`      AS `FQ_MZ`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`FQ_MZ_DMMS` AS `FQ_MZ_DMMS`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`FQ_GMSFZH`  AS `FQ_GMSFZH`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`FQ_LXDH`    AS `FQ_LXDH`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`BZ`         AS `BZ`,
         `intelligence_management_02`.`medical_newborn_record_transfer`.`id`         AS `XXZJBH`
  from `intelligence_management_02`.`medical_newborn_record_transfer`;

